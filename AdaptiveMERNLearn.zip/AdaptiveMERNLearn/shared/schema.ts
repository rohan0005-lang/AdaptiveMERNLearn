import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - students and teachers
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // 'student' or 'teacher'
});

// Quizzes table
export const quizzes = pgTable("quizzes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  difficulty: text("difficulty").notNull(), // 'easy', 'medium', 'hard'
  topic: text("topic").notNull(),
  questions: jsonb("questions").notNull(), // Array of question objects
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz results table
export const results = pgTable("results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  quizId: varchar("quiz_id").notNull(),
  score: integer("score").notNull(), // Percentage score
  correctAnswers: integer("correct_answers").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  accuracy: integer("accuracy").notNull(), // Percentage
  timeTaken: integer("time_taken").notNull(), // In seconds
  aiPrediction: integer("ai_prediction"), // Predicted next quiz score
  answers: jsonb("answers").notNull(), // User's answers
  completedAt: timestamp("completed_at").defaultNow(),
});

// Question type for quiz questions
export const questionSchema = z.object({
  id: z.string(),
  question: z.string(),
  options: z.array(z.string()),
  correctAnswer: z.number(), // Index of correct option
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
}).extend({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  role: z.enum(["student", "teacher"]),
});

export const insertQuizSchema = createInsertSchema(quizzes).omit({
  id: true,
  createdAt: true,
}).extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  difficulty: z.enum(["easy", "medium", "hard"]),
  topic: z.string().min(2, "Topic is required"),
  questions: z.array(questionSchema).min(1, "At least one question is required"),
  createdBy: z.string(),
});

export const insertResultSchema = createInsertSchema(results).omit({
  id: true,
  completedAt: true,
}).extend({
  userId: z.string(),
  quizId: z.string(),
  score: z.number().min(0).max(100),
  correctAnswers: z.number().min(0),
  totalQuestions: z.number().min(1),
  accuracy: z.number().min(0).max(100),
  timeTaken: z.number().min(0),
  aiPrediction: z.number().min(0).max(100).optional(),
  answers: z.array(z.object({
    questionId: z.string(),
    selectedAnswer: z.number(),
  })),
});

// Login schema
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;
export type Result = typeof results.$inferSelect;
export type InsertResult = z.infer<typeof insertResultSchema>;
export type Question = z.infer<typeof questionSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;
