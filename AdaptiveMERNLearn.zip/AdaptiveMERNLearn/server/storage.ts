import { type User, type InsertUser, type Quiz, type InsertQuiz, type Result, type InsertResult } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Quiz methods
  getQuiz(id: string): Promise<Quiz | undefined>;
  getAllQuizzes(): Promise<Quiz[]>;
  getQuizzesByCreator(creatorId: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  deleteQuiz(id: string): Promise<boolean>;
  
  // Result methods
  getResult(id: string): Promise<Result | undefined>;
  getResultsByUser(userId: string): Promise<Result[]>;
  getResultsByQuiz(quizId: string): Promise<Result[]>;
  createResult(result: InsertResult): Promise<Result>;
  
  // Analytics methods
  getStudentStats(userId: string): Promise<{
    totalQuizzes: number;
    averageScore: number;
    completedQuizzes: number;
    streak: number;
  }>;
  
  getTeacherStats(teacherId: string): Promise<{
    totalQuizzes: number;
    totalStudents: number;
    averageScore: number;
    totalAttempts: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private quizzes: Map<string, Quiz>;
  private results: Map<string, Result>;

  constructor() {
    this.users = new Map();
    this.quizzes = new Map();
    this.results = new Map();
    this.seedData();
  }

  // Seed some initial data for testing
  private seedData() {
    // Seed some sample quizzes for demo
    const sampleQuizzes: Quiz[] = [
      {
        id: randomUUID(),
        title: "Introduction to JavaScript",
        description: "Test your basic JavaScript knowledge",
        difficulty: "easy",
        topic: "Programming",
        questions: [
          {
            id: randomUUID(),
            question: "What is the correct syntax for referring to an external script called 'app.js'?",
            options: [
              "<script src='app.js'>",
              "<script href='app.js'>",
              "<script name='app.js'>",
              "<script file='app.js'>"
            ],
            correctAnswer: 0
          },
          {
            id: randomUUID(),
            question: "How do you create a function in JavaScript?",
            options: [
              "function myFunction()",
              "function:myFunction()",
              "create myFunction()",
              "function = myFunction()"
            ],
            correctAnswer: 0
          },
          {
            id: randomUUID(),
            question: "How do you call a function named 'myFunction'?",
            options: [
              "call myFunction()",
              "myFunction()",
              "call function myFunction",
              "Call.myFunction()"
            ],
            correctAnswer: 1
          }
        ],
        createdBy: "system",
        createdAt: new Date()
      },
      {
        id: randomUUID(),
        title: "React Fundamentals",
        description: "Test your understanding of React core concepts",
        difficulty: "medium",
        topic: "Programming",
        questions: [
          {
            id: randomUUID(),
            question: "What is JSX?",
            options: [
              "A JavaScript extension that allows HTML in JavaScript",
              "A CSS framework",
              "A database query language",
              "A testing library"
            ],
            correctAnswer: 0
          },
          {
            id: randomUUID(),
            question: "What hook is used for side effects in React?",
            options: [
              "useState",
              "useEffect",
              "useContext",
              "useReducer"
            ],
            correctAnswer: 1
          }
        ],
        createdBy: "system",
        createdAt: new Date()
      },
      {
        id: randomUUID(),
        title: "Basic Mathematics",
        description: "Test your arithmetic and algebra skills",
        difficulty: "easy",
        topic: "Mathematics",
        questions: [
          {
            id: randomUUID(),
            question: "What is 15 + 27?",
            options: ["42", "32", "52", "41"],
            correctAnswer: 0
          },
          {
            id: randomUUID(),
            question: "What is 8 × 7?",
            options: ["54", "56", "64", "63"],
            correctAnswer: 1
          },
          {
            id: randomUUID(),
            question: "What is the square root of 144?",
            options: ["10", "11", "12", "13"],
            correctAnswer: 2
          }
        ],
        createdBy: "system",
        createdAt: new Date()
      },
      {
        id: randomUUID(),
        title: "Advanced Algebra",
        description: "Challenge yourself with complex algebraic problems",
        difficulty: "hard",
        topic: "Mathematics",
        questions: [
          {
            id: randomUUID(),
            question: "Solve for x: 2x² - 8 = 0",
            options: ["x = ±2", "x = ±4", "x = 2", "x = 4"],
            correctAnswer: 0
          },
          {
            id: randomUUID(),
            question: "What is the slope of the line 3x + 4y = 12?",
            options: ["-3/4", "3/4", "-4/3", "4/3"],
            correctAnswer: 0
          }
        ],
        createdBy: "system",
        createdAt: new Date()
      },
      {
        id: randomUUID(),
        title: "World Geography",
        description: "Test your knowledge of countries and capitals",
        difficulty: "medium",
        topic: "Geography",
        questions: [
          {
            id: randomUUID(),
            question: "What is the capital of Australia?",
            options: ["Sydney", "Melbourne", "Canberra", "Perth"],
            correctAnswer: 2
          },
          {
            id: randomUUID(),
            question: "Which is the largest ocean on Earth?",
            options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
            correctAnswer: 3
          },
          {
            id: randomUUID(),
            question: "How many continents are there?",
            options: ["5", "6", "7", "8"],
            correctAnswer: 2
          }
        ],
        createdBy: "system",
        createdAt: new Date()
      }
    ];

    sampleQuizzes.forEach(quiz => this.quizzes.set(quiz.id, quiz));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Quiz methods
  async getQuiz(id: string): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async getAllQuizzes(): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getQuizzesByCreator(creatorId: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values())
      .filter(quiz => quiz.createdBy === creatorId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = randomUUID();
    const quiz: Quiz = { ...insertQuiz, id, createdAt: new Date() };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  async deleteQuiz(id: string): Promise<boolean> {
    return this.quizzes.delete(id);
  }

  // Result methods
  async getResult(id: string): Promise<Result | undefined> {
    return this.results.get(id);
  }

  async getResultsByUser(userId: string): Promise<Result[]> {
    return Array.from(this.results.values())
      .filter(result => result.userId === userId)
      .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime());
  }

  async getResultsByQuiz(quizId: string): Promise<Result[]> {
    return Array.from(this.results.values())
      .filter(result => result.quizId === quizId);
  }

  async createResult(insertResult: InsertResult): Promise<Result> {
    const id = randomUUID();
    const result: Result = { ...insertResult, id, completedAt: new Date() };
    this.results.set(id, result);
    return result;
  }

  // Analytics methods
  async getStudentStats(userId: string): Promise<{
    totalQuizzes: number;
    averageScore: number;
    completedQuizzes: number;
    streak: number;
  }> {
    const results = await this.getResultsByUser(userId);
    const uniqueQuizzes = new Set(results.map(r => r.quizId));
    
    const averageScore = results.length > 0
      ? Math.round(results.reduce((sum, r) => sum + r.score, 0) / results.length)
      : 0;

    // Calculate streak (consecutive days with quiz activity)
    const dates = results
      .map(r => new Date(r.completedAt!).toDateString())
      .filter((date, index, self) => self.indexOf(date) === index)
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

    let streak = 0;
    const today = new Date().toDateString();
    if (dates.length > 0 && dates[0] === today) {
      streak = 1;
      for (let i = 1; i < dates.length; i++) {
        const diff = Math.floor((new Date(dates[i - 1]).getTime() - new Date(dates[i]).getTime()) / (1000 * 60 * 60 * 24));
        if (diff === 1) streak++;
        else break;
      }
    }

    return {
      totalQuizzes: this.quizzes.size,
      averageScore,
      completedQuizzes: results.length,
      streak
    };
  }

  async getTeacherStats(teacherId: string): Promise<{
    totalQuizzes: number;
    totalStudents: number;
    averageScore: number;
    totalAttempts: number;
  }> {
    const quizzes = await this.getQuizzesByCreator(teacherId);
    const quizIds = quizzes.map(q => q.id);
    
    const relevantResults = Array.from(this.results.values())
      .filter(r => quizIds.includes(r.quizId));

    const uniqueStudents = new Set(relevantResults.map(r => r.userId));
    
    const averageScore = relevantResults.length > 0
      ? Math.round(relevantResults.reduce((sum, r) => sum + r.score, 0) / relevantResults.length)
      : 0;

    return {
      totalQuizzes: quizzes.length,
      totalStudents: uniqueStudents.size,
      averageScore,
      totalAttempts: relevantResults.length
    };
  }
}

export const storage = new MemStorage();
