import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, insertQuizSchema, insertResultSchema, type User } from "@shared/schema";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { z } from "zod";

const JWT_SECRET = process.env.SESSION_SECRET || "your-secret-key-change-in-production";
const SALT_ROUNDS = 10;

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

// Authentication middleware
const authenticateToken = async (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Authentication required" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const user = await storage.getUser(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: "Invalid or expired token" });
  }
};

// Role-based authorization middleware
const requireRole = (role: "student" | "teacher") => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    if (req.user.role !== role) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }
    
    next();
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth Routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, SALT_ROUNDS);
      
      // Create user
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword
      });

      // Generate JWT
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(validatedData.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(validatedData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Generate JWT
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Quiz Routes
  app.get("/api/quizzes", async (req, res) => {
    try {
      const quizzes = await storage.getAllQuizzes();
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/quizzes/:id", async (req, res) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      res.json(quiz);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/quizzes", authenticateToken, requireRole("teacher"), async (req, res) => {
    try {
      const validatedData = insertQuizSchema.parse(req.body);
      const quiz = await storage.createQuiz(validatedData);
      res.status(201).json(quiz);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/quizzes/:id", authenticateToken, requireRole("teacher"), async (req, res) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      // Check if teacher owns this quiz
      if (quiz.createdBy !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized to delete this quiz" });
      }

      await storage.deleteQuiz(req.params.id);
      res.json({ message: "Quiz deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Result Routes
  app.post("/api/results", authenticateToken, requireRole("student"), async (req, res) => {
    try {
      const validatedData = insertResultSchema.parse(req.body);
      
      // Ensure the result belongs to the authenticated user
      if (validatedData.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      const result = await storage.createResult(validatedData);
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/results/:id", authenticateToken, async (req, res) => {
    try {
      const result = await storage.getResult(req.params.id);
      if (!result) {
        return res.status(404).json({ message: "Result not found" });
      }

      // Students can only see their own results
      if (req.user!.role === "student" && result.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Student Analytics Routes
  app.get("/api/student/stats", authenticateToken, requireRole("student"), async (req, res) => {
    try {
      const stats = await storage.getStudentStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/student/results", authenticateToken, requireRole("student"), async (req, res) => {
    try {
      const results = await storage.getResultsByUser(req.user!.id);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/student/results/recent", authenticateToken, requireRole("student"), async (req, res) => {
    try {
      const results = await storage.getResultsByUser(req.user!.id);
      res.json(results.slice(0, 5));
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/student/recommendations", authenticateToken, requireRole("student"), async (req, res) => {
    try {
      const results = await storage.getResultsByUser(req.user!.id);
      const allQuizzes = await storage.getAllQuizzes();
      
      // Get completed quiz IDs
      const completedQuizIds = new Set(results.map(r => r.quizId));
      
      // Filter out completed quizzes
      let availableQuizzes = allQuizzes.filter(q => !completedQuizIds.has(q.id));
      
      // If user has results, recommend based on performance
      if (results.length > 0) {
        const avgScore = results.reduce((sum, r) => sum + r.score, 0) / results.length;
        
        // Recommend easier quizzes if struggling, harder if doing well
        if (avgScore < 60) {
          availableQuizzes = availableQuizzes
            .sort((a, b) => {
              const difficultyOrder: Record<string, number> = { easy: 1, medium: 2, hard: 3 };
              return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
            });
        } else if (avgScore > 80) {
          availableQuizzes = availableQuizzes
            .sort((a, b) => {
              const difficultyOrder: Record<string, number> = { easy: 1, medium: 2, hard: 3 };
              return difficultyOrder[b.difficulty] - difficultyOrder[a.difficulty];
            });
        }
      }
      
      res.json(availableQuizzes.slice(0, 6));
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Teacher Analytics Routes
  app.get("/api/teacher/stats", authenticateToken, requireRole("teacher"), async (req, res) => {
    try {
      const stats = await storage.getTeacherStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/teacher/quizzes", authenticateToken, requireRole("teacher"), async (req, res) => {
    try {
      const quizzes = await storage.getQuizzesByCreator(req.user!.id);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
