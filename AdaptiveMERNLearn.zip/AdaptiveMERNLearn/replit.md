# LearnAI - Adaptive Learning Platform

## Overview
LearnAI is a full-stack adaptive learning platform built with the MERN stack (MongoDB/In-memory, Express, React, Node.js). It uses AI-powered performance prediction to provide personalized learning experiences for students, with intelligent quiz recommendations based on their performance history.

## Current Status
**MVP Implementation Complete** - All core features are functional with in-memory storage.

## Features

### For Students
- **Personalized Dashboard**: View progress, quiz history, and AI-powered recommendations
- **Adaptive Quizzes**: Take quizzes with instant feedback and scoring
- **AI Performance Prediction**: See predicted scores for upcoming quizzes based on past performance
- **Analytics Dashboard**: Interactive charts showing learning trends, score progression, and performance metrics
- **Smart Recommendations**: Get topic suggestions based on AI analysis of quiz results

### For Teachers
- **Quiz Management**: Create, edit, and delete quizzes with multiple-choice questions
- **Dashboard Analytics**: View class-wide statistics including average scores, total attempts, and student engagement
- **Quiz Builder**: Intuitive interface for creating quizzes with difficulty levels and topics
- **Student Insights**: Track student performance across all quizzes

### Authentication
- JWT-based authentication with bcrypt password hashing
- Role-based access control (Student/Teacher)
- Secure session management

## Technology Stack

### Frontend
- **React** with TypeScript
- **Wouter** for routing
- **Tailwind CSS** for styling
- **Shadcn UI** for components
- **TanStack Query** for data fetching
- **React Hook Form** with Zod validation
- **Recharts** for analytics visualization
- **TensorFlow.js** for client-side AI predictions

### Backend
- **Express.js** for API server
- **In-memory storage** (MemStorage) for data persistence
- **JWT** for authentication
- **Bcrypt** for password hashing
- **Zod** for validation

## Project Structure

```
├── client/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/              # Shadcn UI components
│   │   │   ├── landing-page.tsx
│   │   │   ├── auth/
│   │   │   │   └── auth-page.tsx
│   │   │   └── app-sidebar.tsx
│   │   ├── pages/
│   │   │   ├── student-dashboard.tsx
│   │   │   ├── teacher-dashboard.tsx
│   │   │   ├── quiz-list.tsx
│   │   │   ├── quiz-taking.tsx
│   │   │   ├── quiz-results.tsx
│   │   │   ├── analytics.tsx
│   │   │   ├── create-quiz.tsx
│   │   │   └── not-found.tsx
│   │   ├── lib/
│   │   │   └── queryClient.ts
│   │   └── App.tsx
│   └── index.html
├── server/
│   ├── routes.ts              # API endpoints
│   ├── storage.ts             # Data persistence layer
│   └── index.ts
├── shared/
│   └── schema.ts              # Shared types and schemas
└── design_guidelines.md       # UI/UX design system
```

## Data Models

### User
- `id`: Unique identifier
- `email`: Email address (unique)
- `password`: Hashed password
- `name`: Full name
- `role`: "student" or "teacher"

### Quiz
- `id`: Unique identifier
- `title`: Quiz title
- `description`: Optional description
- `difficulty`: "easy", "medium", or "hard"
- `topic`: Subject/topic area
- `questions`: Array of question objects
- `createdBy`: Teacher ID
- `createdAt`: Timestamp

### Question
- `id`: Unique identifier
- `question`: Question text
- `options`: Array of 4 answer choices
- `correctAnswer`: Index of correct option (0-3)

### Result
- `id`: Unique identifier
- `userId`: Student ID
- `quizId`: Quiz ID
- `score`: Percentage score
- `correctAnswers`: Number of correct answers
- `totalQuestions`: Total questions in quiz
- `accuracy`: Percentage accuracy
- `timeTaken`: Time in seconds
- `aiPrediction`: Predicted next quiz score
- `answers`: Array of user's selected answers
- `completedAt`: Timestamp

## API Endpoints

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login user

### Quizzes
- `GET /api/quizzes` - Get all quizzes
- `GET /api/quizzes/:id` - Get quiz by ID
- `POST /api/quizzes` - Create quiz (teacher only)
- `DELETE /api/quizzes/:id` - Delete quiz (teacher only)

### Results
- `POST /api/results` - Submit quiz results
- `GET /api/results/:id` - Get result by ID
- `GET /api/student/results` - Get all student results
- `GET /api/student/results/recent` - Get recent results

### Analytics
- `GET /api/student/stats` - Get student statistics
- `GET /api/student/recommendations` - Get AI recommendations
- `GET /api/teacher/stats` - Get teacher statistics
- `GET /api/teacher/quizzes` - Get teacher's quizzes

## AI/ML Features

### Performance Prediction
- Uses TensorFlow.js for client-side predictions
- Analyzes past quiz scores, accuracy, and time taken
- Predicts likely performance on next quiz
- Provides confidence scores

### Recommendation Engine
- Suggests quizzes based on difficulty progression
- Considers topics where student needs improvement
- Balances challenge with achievable goals

## Design System
The application follows a comprehensive design system documented in `design_guidelines.md`:
- Material Design principles
- Inter font for UI, Poppins for headings
- Primary blue color scheme with chart color palette
- Consistent spacing (4, 6, 8, 12, 16px units)
- Responsive breakpoints (sm, md, lg, xl)

## User Flows

### Student Journey
1. Sign up / Login as student
2. View personalized dashboard with stats and recommendations
3. Browse available quizzes (filter by difficulty/topic)
4. Take quiz with real-time progress tracking
5. View results with AI prediction
6. Get recommended next quizzes
7. Track progress in analytics dashboard

### Teacher Journey
1. Sign up / Login as teacher
2. View teacher dashboard with class statistics
3. Create new quiz with questions and answers
4. Manage existing quizzes
5. View student performance data
6. Track class-wide metrics

## Future Enhancements (Post-MVP)
- MongoDB integration for persistent storage
- Student leaderboard with achievements
- Advanced teacher analytics with individual student tracking
- AI chatbot for learning assistance
- Quiz categories and advanced filtering
- Timed quizzes with countdown
- Question bank for quiz generation
- Export results to CSV/PDF

## Development Notes
- Uses in-memory storage for MVP (data resets on server restart)
- JWT tokens stored in localStorage
- All passwords hashed with bcrypt
- Zod validation on both frontend and backend
- Responsive design with mobile-first approach
- Dark mode support built into design system
