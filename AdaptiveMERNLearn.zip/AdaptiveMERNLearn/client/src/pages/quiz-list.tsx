import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { Quiz } from "@shared/schema";
import { Search, BookOpen, FileQuestion, ArrowRight, Brain } from "lucide-react";

export function QuizList() {
  const [searchTerm, setSearchTerm] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");
  const [topicFilter, setTopicFilter] = useState<string>("all");

  const { data: quizzes, isLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  const filteredQuizzes = quizzes?.filter((quiz) => {
    const matchesSearch = quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         quiz.topic.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDifficulty = difficultyFilter === "all" || quiz.difficulty === difficultyFilter;
    const matchesTopic = topicFilter === "all" || quiz.topic === topicFilter;
    return matchesSearch && matchesDifficulty && matchesTopic;
  });

  const topics = Array.from(new Set(quizzes?.map(q => q.topic) || []));

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-screen-2xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="font-heading font-bold text-3xl md:text-4xl" data-testid="text-page-title">
          Available Quizzes
        </h1>
        <p className="text-muted-foreground text-lg">
          Choose a quiz to test your knowledge and improve your skills
        </p>
      </div>

      {/* Filters */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search quizzes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search"
          />
        </div>

        <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
          <SelectTrigger data-testid="select-difficulty">
            <SelectValue placeholder="All Difficulties" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Difficulties</SelectItem>
            <SelectItem value="easy">Easy</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="hard">Hard</SelectItem>
          </SelectContent>
        </Select>

        <Select value={topicFilter} onValueChange={setTopicFilter}>
          <SelectTrigger data-testid="select-topic">
            <SelectValue placeholder="All Topics" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Topics</SelectItem>
            {topics.map((topic) => (
              <SelectItem key={topic} value={topic}>{topic}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Quiz Grid */}
      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i}>
              <CardContent className="p-6 h-64 bg-muted/50" />
            </Card>
          ))}
        </div>
      ) : filteredQuizzes && filteredQuizzes.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredQuizzes.map((quiz) => (
            <Card 
              key={quiz.id} 
              className="hover-elevate transition-all group"
              data-testid={`card-quiz-${quiz.id}`}
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <CardTitle className="text-xl line-clamp-2 flex-1">{quiz.title}</CardTitle>
                  <Badge 
                    variant={
                      quiz.difficulty === "easy" ? "secondary" : 
                      quiz.difficulty === "medium" ? "default" : 
                      "destructive"
                    }
                    className="capitalize shrink-0"
                  >
                    {quiz.difficulty}
                  </Badge>
                </div>
                <CardDescription className="line-clamp-3">
                  {quiz.description || "Test your knowledge and improve your skills"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    <span className="line-clamp-1">{quiz.topic}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileQuestion className="w-4 h-4" />
                    <span>{(quiz.questions as any[]).length} questions</span>
                  </div>
                </div>
                <Link href={`/student/quiz/${quiz.id}`}>
                  <Button className="w-full group-hover:translate-x-0.5 transition-transform" data-testid={`button-start-${quiz.id}`}>
                    Start Quiz
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center space-y-4">
            <div className="mx-auto w-fit p-4 rounded-full bg-muted">
              <Brain className="w-12 h-12 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-lg">No quizzes found</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                {searchTerm || difficultyFilter !== "all" || topicFilter !== "all"
                  ? "Try adjusting your filters to see more quizzes"
                  : "There are no quizzes available at the moment"
                }
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
