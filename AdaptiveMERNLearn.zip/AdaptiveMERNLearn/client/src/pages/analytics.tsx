import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Result } from "@shared/schema";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { TrendingUp, Target, Clock, BarChart3 } from "lucide-react";

export function Analytics() {
  const { data: results, isLoading } = useQuery<Result[]>({
    queryKey: ["/api/student/results"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="space-y-6 animate-pulse">
          <div className="h-8 bg-muted rounded w-48" />
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2].map(i => (
              <Card key={i}>
                <CardContent className="p-6 h-80 bg-muted/50" />
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Prepare data for charts
  const scoreData = results?.map((result, index) => ({
    name: `Quiz ${index + 1}`,
    score: result.score,
    aiPrediction: result.aiPrediction || 0,
    date: new Date(result.completedAt!).toLocaleDateString(),
  })) || [];

  const accuracyData = results?.map((result, index) => ({
    name: `Quiz ${index + 1}`,
    accuracy: result.accuracy,
  })) || [];

  const avgScore = results?.length 
    ? Math.round(results.reduce((acc, r) => acc + r.score, 0) / results.length)
    : 0;

  const avgTime = results?.length
    ? Math.round(results.reduce((acc, r) => acc + r.timeTaken, 0) / results.length)
    : 0;

  const improvement = results && results.length >= 2
    ? results[results.length - 1].score - results[0].score
    : 0;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-screen-2xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="font-heading font-bold text-3xl md:text-4xl" data-testid="text-page-title">
          Your Analytics
        </h1>
        <p className="text-muted-foreground text-lg">
          Track your learning progress and performance trends
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="hover-elevate transition-all" data-testid="card-avg-score">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Average Score</p>
                <p className="text-3xl font-bold text-foreground">{avgScore}%</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-2/10">
                <Target className="w-8 h-8 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-improvement">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Improvement</p>
                <p className={`text-3xl font-bold ${improvement >= 0 ? 'text-chart-2' : 'text-destructive'}`}>
                  {improvement > 0 ? '+' : ''}{improvement}%
                </p>
              </div>
              <div className="p-3 rounded-xl bg-chart-4/10">
                <TrendingUp className="w-8 h-8 text-chart-4" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-avg-time">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Avg. Time</p>
                <p className="text-3xl font-bold text-foreground">{formatTime(avgTime)}</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-3/10">
                <Clock className="w-8 h-8 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {results && results.length > 0 ? (
        <>
          {/* Score Trends Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5" />
                Score Trends Over Time
              </CardTitle>
              <CardDescription>
                Your performance progression with AI predictions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={scoreData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis 
                    dataKey="name" 
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    domain={[0, 100]}
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="hsl(var(--chart-1))" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--chart-1))', r: 5 }}
                    name="Actual Score"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="aiPrediction" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: 'hsl(var(--chart-2))', r: 4 }}
                    name="AI Prediction"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Accuracy Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <BarChart3 className="w-5 h-5" />
                Accuracy Analysis
              </CardTitle>
              <CardDescription>
                Your answer accuracy across different quizzes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={accuracyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis 
                    dataKey="name"
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    domain={[0, 100]}
                    className="text-xs"
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar 
                    dataKey="accuracy" 
                    fill="hsl(var(--chart-4))"
                    radius={[8, 8, 0, 0]}
                    name="Accuracy %"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Recent Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Performance Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {results.slice(-5).reverse().map((result, index) => (
                  <div 
                    key={result.id}
                    className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-lg border bg-card hover-elevate transition-all"
                    data-testid={`result-summary-${index}`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold">Quiz #{results.length - index}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(result.completedAt!).toLocaleString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 flex-wrap">
                      <div className="text-center">
                        <div className="text-2xl font-bold">{result.score}%</div>
                        <div className="text-xs text-muted-foreground">Score</div>
                      </div>
                      <Badge 
                        variant={result.score >= 75 ? "default" : result.score >= 60 ? "secondary" : "destructive"}
                      >
                        {result.correctAnswers}/{result.totalQuestions} correct
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card>
          <CardContent className="p-12 text-center space-y-4">
            <div className="mx-auto w-fit p-4 rounded-full bg-muted">
              <BarChart3 className="w-12 h-12 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-lg">No analytics data yet</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Complete some quizzes to see your performance trends and analytics
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
