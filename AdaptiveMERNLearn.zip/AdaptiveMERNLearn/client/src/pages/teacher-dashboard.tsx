import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  FileQuestion, 
  Users, 
  TrendingUp, 
  Plus,
  Trash2,
  Eye,
  BookOpen,
  BarChart3
} from "lucide-react";
import { Quiz } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function TeacherDashboard() {
  const { toast } = useToast();

  const { data: stats, isLoading: statsLoading } = useQuery<{
    totalQuizzes: number;
    totalStudents: number;
    averageScore: number;
    totalAttempts: number;
  }>({
    queryKey: ["/api/teacher/stats"],
  });

  const { data: quizzes, isLoading: quizzesLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/teacher/quizzes"],
  });

  const deleteQuizMutation = useMutation({
    mutationFn: async (quizId: string) => {
      return await apiRequest("DELETE", `/api/quizzes/${quizId}`, {});
    },
    onSuccess: () => {
      toast({ title: "Quiz deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/quizzes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/stats"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to delete quiz", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  if (statsLoading) {
    return (
      <div className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-pulse">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-6 h-32 bg-muted/50" />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-screen-2xl mx-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-2">
          <h1 className="font-heading font-bold text-3xl md:text-4xl" data-testid="text-welcome">
            Teacher Dashboard
          </h1>
          <p className="text-muted-foreground text-lg">
            Manage your quizzes and track student performance
          </p>
        </div>
        <Link href="/teacher/create-quiz">
          <Button size="lg" className="gap-2" data-testid="button-create-quiz">
            <Plus className="w-5 h-5" />
            Create New Quiz
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="hover-elevate transition-all" data-testid="card-total-quizzes">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Total Quizzes</p>
                <p className="text-3xl font-bold text-foreground">{stats?.totalQuizzes || 0}</p>
              </div>
              <div className="p-3 rounded-xl bg-primary/10">
                <FileQuestion className="w-8 h-8 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-total-students">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Active Students</p>
                <p className="text-3xl font-bold text-chart-2">{stats?.totalStudents || 0}</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-2/10">
                <Users className="w-8 h-8 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-average-score">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Average Score</p>
                <p className="text-3xl font-bold text-chart-4">{stats?.averageScore || 0}%</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-4/10">
                <TrendingUp className="w-8 h-8 text-chart-4" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-total-attempts">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Total Attempts</p>
                <p className="text-3xl font-bold text-chart-3">{stats?.totalAttempts || 0}</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-3/10">
                <BarChart3 className="w-8 h-8 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quiz Management */}
      <div className="space-y-4">
        <h2 className="font-heading font-semibold text-2xl">Your Quizzes</h2>

        {quizzesLoading ? (
          <div className="space-y-4 animate-pulse">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardContent className="p-6 h-32 bg-muted/50" />
              </Card>
            ))}
          </div>
        ) : quizzes && quizzes.length > 0 ? (
          <div className="space-y-4">
            {quizzes.map((quiz) => (
              <Card 
                key={quiz.id} 
                className="hover-elevate transition-all"
                data-testid={`card-quiz-${quiz.id}`}
              >
                <CardHeader>
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex items-center gap-3 flex-wrap">
                        <CardTitle className="text-xl">{quiz.title}</CardTitle>
                        <Badge 
                          variant={
                            quiz.difficulty === "easy" ? "secondary" : 
                            quiz.difficulty === "medium" ? "default" : 
                            "destructive"
                          }
                          className="capitalize"
                        >
                          {quiz.difficulty}
                        </Badge>
                      </div>
                      <CardDescription className="line-clamp-2">
                        {quiz.description || "No description provided"}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Link href={`/teacher/quiz/${quiz.id}/results`}>
                        <Button variant="outline" size="sm" data-testid={`button-view-results-${quiz.id}`}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Results
                        </Button>
                      </Link>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm"
                            data-testid={`button-delete-${quiz.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Quiz?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete "{quiz.title}" and all associated results. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deleteQuizMutation.mutate(quiz.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4" />
                      <span>{quiz.topic}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileQuestion className="w-4 h-4" />
                      <span>{(quiz.questions as any[]).length} questions</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Created {new Date(quiz.createdAt!).toLocaleDateString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center space-y-4">
              <div className="mx-auto w-fit p-4 rounded-full bg-muted">
                <FileQuestion className="w-12 h-12 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">No quizzes yet</h3>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Create your first quiz to start engaging with students
                </p>
              </div>
              <Link href="/teacher/create-quiz">
                <Button data-testid="button-create-first-quiz">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Quiz
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
