import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Clock, 
  CheckCircle2,
  ArrowRight,
  Brain,
  Zap,
  Star
} from "lucide-react";
import { Result, Quiz } from "@shared/schema";

export function StudentDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<{
    totalQuizzes: number;
    averageScore: number;
    completedQuizzes: number;
    streak: number;
  }>({
    queryKey: ["/api/student/stats"],
  });

  const { data: recentResults, isLoading: resultsLoading } = useQuery<Result[]>({
    queryKey: ["/api/student/results/recent"],
  });

  const { data: recommendations, isLoading: recsLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/student/recommendations"],
  });

  if (statsLoading) {
    return (
      <div className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-pulse">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-6 h-32 bg-muted/50" />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const progressPercentage = stats?.completedQuizzes 
    ? Math.min((stats.completedQuizzes / 10) * 100, 100) 
    : 0;

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-screen-2xl mx-auto">
      {/* Welcome Banner */}
      <div className="space-y-2">
        <h1 className="font-heading font-bold text-3xl md:text-4xl" data-testid="text-welcome">
          Welcome back! 🎓
        </h1>
        <p className="text-muted-foreground text-lg">
          Continue your learning journey and reach new milestones
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="hover-elevate transition-all" data-testid="card-total-quizzes">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Total Quizzes</p>
                <p className="text-3xl font-bold text-foreground">{stats?.completedQuizzes || 0}</p>
              </div>
              <div className="p-3 rounded-xl bg-primary/10">
                <CheckCircle2 className="w-8 h-8 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-average-score">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Average Score</p>
                <p className="text-3xl font-bold text-chart-2">{stats?.averageScore || 0}%</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-2/10">
                <Trophy className="w-8 h-8 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-streak">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">Current Streak</p>
                <p className="text-3xl font-bold text-chart-4">{stats?.streak || 0} days</p>
              </div>
              <div className="p-3 rounded-xl bg-chart-4/10">
                <Zap className="w-8 h-8 text-chart-4" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all" data-testid="card-progress">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground font-medium">Overall Progress</p>
                <Target className="w-5 h-5 text-chart-3" />
              </div>
              <div className="space-y-2">
                <Progress value={progressPercentage} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {stats?.completedQuizzes || 0}/10 quizzes completed
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommended Topics */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-heading font-semibold text-2xl">Recommended for You</h2>
            <p className="text-sm text-muted-foreground mt-1">
              AI-powered quiz suggestions based on your performance
            </p>
          </div>
        </div>

        {recsLoading ? (
          <div className="grid md:grid-cols-2 gap-6 animate-pulse">
            {[1, 2].map(i => (
              <Card key={i}>
                <CardContent className="p-6 h-40 bg-muted/50" />
              </Card>
            ))}
          </div>
        ) : recommendations && recommendations.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {recommendations.slice(0, 4).map((quiz) => (
              <Card 
                key={quiz.id} 
                className="hover-elevate transition-all group"
                data-testid={`card-quiz-${quiz.id}`}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <CardTitle className="text-xl line-clamp-1">{quiz.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {quiz.description || "Test your knowledge and improve your skills"}
                      </CardDescription>
                    </div>
                    <Badge 
                      variant={
                        quiz.difficulty === "easy" ? "secondary" : 
                        quiz.difficulty === "medium" ? "default" : 
                        "destructive"
                      }
                      className="capitalize shrink-0"
                    >
                      {quiz.difficulty}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-6 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      <span>{quiz.topic}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileQuestion className="w-4 h-4" />
                      <span>{(quiz.questions as any[]).length} questions</span>
                    </div>
                  </div>
                  <Link href={`/student/quiz/${quiz.id}`}>
                    <Button className="w-full" data-testid={`button-start-quiz-${quiz.id}`}>
                      Start Quiz
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center space-y-4">
              <div className="mx-auto w-fit p-4 rounded-full bg-muted">
                <Brain className="w-12 h-12 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">No recommendations yet</h3>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Complete some quizzes to get personalized AI-powered recommendations
                </p>
              </div>
              <Link href="/student/quizzes">
                <Button data-testid="button-browse-quizzes">
                  Browse All Quizzes
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Recent Quiz Results */}
      <div className="space-y-4">
        <h2 className="font-heading font-semibold text-2xl">Recent Quiz Results</h2>
        
        {resultsLoading ? (
          <div className="space-y-3 animate-pulse">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardContent className="p-4 h-20 bg-muted/50" />
              </Card>
            ))}
          </div>
        ) : recentResults && recentResults.length > 0 ? (
          <div className="space-y-3">
            {recentResults.slice(0, 5).map((result) => (
              <Card 
                key={result.id} 
                className="hover-elevate transition-all"
                data-testid={`card-result-${result.id}`}
              >
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-base">Quiz Result</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(result.completedAt!).toLocaleDateString()} at {new Date(result.completedAt!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-foreground">{result.score}%</div>
                        <div className="text-xs text-muted-foreground">Score</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-sm font-semibold text-muted-foreground">
                          {result.correctAnswers}/{result.totalQuestions}
                        </div>
                        <div className="text-xs text-muted-foreground">Correct</div>
                      </div>

                      {result.aiPrediction && (
                        <Badge variant="secondary" className="gap-1.5">
                          <Star className="w-3 h-3" />
                          AI: {result.aiPrediction}%
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center space-y-4">
              <div className="mx-auto w-fit p-4 rounded-full bg-muted">
                <TrendingUp className="w-12 h-12 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">No quiz results yet</h3>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Start taking quizzes to track your progress and see AI predictions
                </p>
              </div>
              <Link href="/student/quizzes">
                <Button data-testid="button-take-first-quiz">
                  Take Your First Quiz
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

import { FileQuestion } from "lucide-react";
