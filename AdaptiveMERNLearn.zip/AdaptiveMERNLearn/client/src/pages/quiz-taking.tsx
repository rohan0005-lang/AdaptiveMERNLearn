import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Quiz, Question, Result } from "@shared/schema";
import { ChevronLeft, ChevronRight, CheckCircle2, Clock } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { predictNextScore } from "@/lib/ai-prediction";

export function QuizTaking() {
  const [, params] = useRoute("/student/quiz/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const quizId = params?.id;

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [startTime] = useState(Date.now());
  const [timeElapsed, setTimeElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [startTime]);

  const { data: quiz, isLoading } = useQuery<Quiz>({
    queryKey: ["/api/quizzes", quizId],
    enabled: !!quizId,
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/results", data);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/student/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/student/results/recent"] });
      setLocation(`/student/results/${data.id}`);
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to submit quiz", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  if (isLoading || !quiz) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto" />
          <p className="text-muted-foreground">Loading quiz...</p>
        </div>
      </div>
    );
  }

  const questions = quiz.questions as Question[];
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  const isLastQuestion = currentQuestionIndex === questions.length - 1;
  const hasAnsweredCurrent = answers[currentQuestion.id] !== undefined;

  const handleAnswer = (optionIndex: number) => {
    setAnswers({ ...answers, [currentQuestion.id]: optionIndex });
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmit = async () => {
    // Calculate score
    let correctAnswers = 0;
    const answerArray = questions.map((q) => ({
      questionId: q.id,
      selectedAnswer: answers[q.id] ?? -1,
    }));

    questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correctAnswers++;
      }
    });

    const score = Math.round((correctAnswers / questions.length) * 100);
    const accuracy = Math.round((correctAnswers / questions.length) * 100);

    const user = JSON.parse(localStorage.getItem("user") || "{}");

    // Get past results for AI prediction
    try {
      const pastResults = await apiRequest("GET", "/api/student/results", undefined);
      const aiPrediction = await predictNextScore(pastResults);

      submitQuizMutation.mutate({
        userId: user.id,
        quizId: quiz.id,
        score,
        correctAnswers,
        totalQuestions: questions.length,
        accuracy,
        timeTaken: timeElapsed,
        aiPrediction,
        answers: answerArray,
      });
    } catch (error) {
      // Submit without AI prediction if it fails
      submitQuizMutation.mutate({
        userId: user.id,
        quizId: quiz.id,
        score,
        correctAnswers,
        totalQuestions: questions.length,
        accuracy,
        timeTaken: timeElapsed,
        answers: answerArray,
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header with Progress */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-heading font-bold text-2xl md:text-3xl" data-testid="text-quiz-title">
                {quiz.title}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Question {currentQuestionIndex + 1} of {questions.length}
              </p>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground" data-testid="text-timer">
              <Clock className="w-5 h-5" />
              <span className="font-mono text-lg font-semibold">{formatTime(timeElapsed)}</span>
            </div>
          </div>
          <Progress value={progress} className="h-2" data-testid="progress-quiz" />
        </div>

        {/* Question Card */}
        <Card className="border-2">
          <CardHeader className="pb-6">
            <CardTitle className="text-xl md:text-2xl leading-relaxed" data-testid={`text-question-${currentQuestionIndex}`}>
              {currentQuestion.question}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <RadioGroup
              value={answers[currentQuestion.id]?.toString()}
              onValueChange={(val) => handleAnswer(parseInt(val))}
            >
              <div className="space-y-3">
                {currentQuestion.options.map((option, index) => (
                  <Label
                    key={index}
                    htmlFor={`option-${index}`}
                    className={`
                      flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all
                      hover-elevate
                      ${answers[currentQuestion.id] === index 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border bg-card'
                      }
                    `}
                    data-testid={`option-${index}`}
                  >
                    <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                    <span className="flex-1 text-base">{option}</span>
                    {answers[currentQuestion.id] === index && (
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    )}
                  </Label>
                ))}
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between gap-4 pt-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
            data-testid="button-previous"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <div className="text-sm text-muted-foreground">
            {Object.keys(answers).length} of {questions.length} answered
          </div>

          {isLastQuestion ? (
            <Button
              onClick={handleSubmit}
              disabled={Object.keys(answers).length !== questions.length || submitQuizMutation.isPending}
              size="lg"
              data-testid="button-submit-quiz"
            >
              {submitQuizMutation.isPending ? "Submitting..." : "Submit Quiz"}
            </Button>
          ) : (
            <Button
              onClick={handleNext}
              disabled={!hasAnsweredCurrent}
              data-testid="button-next"
            >
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
