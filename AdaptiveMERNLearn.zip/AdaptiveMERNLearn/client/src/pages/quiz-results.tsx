import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Result, Quiz, Question } from "@shared/schema";
import { 
  Trophy, 
  Target, 
  Clock, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  ArrowRight,
  Star,
  Brain
} from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export function QuizResults() {
  const [, params] = useRoute("/student/results/:id");
  const resultId = params?.id;

  const { data: result, isLoading: resultLoading } = useQuery<Result>({
    queryKey: ["/api/results", resultId],
    enabled: !!resultId,
  });

  const { data: quiz, isLoading: quizLoading } = useQuery<Quiz>({
    queryKey: ["/api/quizzes", result?.quizId],
    enabled: !!result?.quizId,
  });

  const { data: recommendations } = useQuery<Quiz[]>({
    queryKey: ["/api/student/recommendations"],
  });

  if (resultLoading || quizLoading || !result || !quiz) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto" />
          <p className="text-muted-foreground">Loading results...</p>
        </div>
      </div>
    );
  }

  const questions = quiz.questions as Question[];
  const userAnswers = result.answers as any[];
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const getPerformanceMessage = (score: number) => {
    if (score >= 90) return { message: "Outstanding! 🎉", color: "text-chart-2" };
    if (score >= 75) return { message: "Great job! 👏", color: "text-chart-4" };
    if (score >= 60) return { message: "Good effort! 💪", color: "text-primary" };
    return { message: "Keep practicing! 📚", color: "text-chart-5" };
  };

  const performance = getPerformanceMessage(result.score);

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Results Hero */}
        <Card className="bg-gradient-to-br from-primary/10 via-background to-chart-2/10 border-2">
          <CardContent className="p-8 md:p-12 text-center space-y-6">
            <div className="mx-auto w-fit p-4 rounded-full bg-primary/10">
              <Trophy className="w-16 h-16 text-primary" />
            </div>
            
            <div className="space-y-2">
              <h1 className={`font-heading font-bold text-5xl md:text-6xl ${performance.color}`} data-testid="text-score">
                {result.score}%
              </h1>
              <p className="text-xl font-semibold text-foreground">{performance.message}</p>
              <p className="text-muted-foreground">Quiz completed successfully</p>
            </div>

            {result.aiPrediction && (
              <Badge variant="secondary" className="text-base px-4 py-2 gap-2" data-testid="badge-ai-prediction">
                <Star className="w-4 h-4" />
                AI Predicted: {result.aiPrediction}% for your next quiz
              </Badge>
            )}
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center space-y-2">
              <div className="mx-auto w-fit p-3 rounded-xl bg-chart-2/10">
                <Target className="w-8 h-8 text-chart-2" />
              </div>
              <div className="text-3xl font-bold text-foreground" data-testid="text-correct-answers">
                {result.correctAnswers}/{result.totalQuestions}
              </div>
              <p className="text-sm text-muted-foreground">Correct Answers</p>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center space-y-2">
              <div className="mx-auto w-fit p-3 rounded-xl bg-chart-4/10">
                <TrendingUp className="w-8 h-8 text-chart-4" />
              </div>
              <div className="text-3xl font-bold text-foreground">{result.accuracy}%</div>
              <p className="text-sm text-muted-foreground">Accuracy</p>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all">
            <CardContent className="p-6 text-center space-y-2">
              <div className="mx-auto w-fit p-3 rounded-xl bg-chart-3/10">
                <Clock className="w-8 h-8 text-chart-3" />
              </div>
              <div className="text-3xl font-bold text-foreground" data-testid="text-time-taken">
                {formatTime(result.timeTaken)}
              </div>
              <p className="text-sm text-muted-foreground">Time Taken</p>
            </CardContent>
          </Card>
        </div>

        {/* Question by Question Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Question Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {questions.map((question, index) => {
                const userAnswer = userAnswers.find(a => a.questionId === question.id);
                const isCorrect = userAnswer?.selectedAnswer === question.correctAnswer;
                
                return (
                  <AccordionItem key={question.id} value={`question-${index}`}>
                    <AccordionTrigger className="hover:no-underline" data-testid={`accordion-question-${index}`}>
                      <div className="flex items-center gap-4 flex-1 text-left">
                        {isCorrect ? (
                          <CheckCircle2 className="w-6 h-6 text-chart-2 shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-destructive shrink-0" />
                        )}
                        <div className="flex-1">
                          <span className="font-medium">Question {index + 1}</span>
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                            {question.question}
                          </p>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-4 space-y-4">
                      <div className="space-y-3">
                        <p className="text-base font-medium">{question.question}</p>
                        
                        <div className="space-y-2">
                          {question.options.map((option, optIndex) => {
                            const isUserAnswer = userAnswer?.selectedAnswer === optIndex;
                            const isCorrectAnswer = question.correctAnswer === optIndex;
                            
                            return (
                              <div
                                key={optIndex}
                                className={`
                                  p-3 rounded-lg border-2 transition-all
                                  ${isCorrectAnswer 
                                    ? 'border-chart-2 bg-chart-2/10' 
                                    : isUserAnswer && !isCorrect
                                    ? 'border-destructive bg-destructive/10'
                                    : 'border-border bg-card'
                                  }
                                `}
                              >
                                <div className="flex items-center gap-3">
                                  {isCorrectAnswer && (
                                    <CheckCircle2 className="w-5 h-5 text-chart-2" />
                                  )}
                                  {isUserAnswer && !isCorrect && (
                                    <XCircle className="w-5 h-5 text-destructive" />
                                  )}
                                  <span className="flex-1">{option}</span>
                                  {isCorrectAnswer && (
                                    <Badge variant="secondary">Correct</Badge>
                                  )}
                                  {isUserAnswer && !isCorrect && (
                                    <Badge variant="destructive">Your answer</Badge>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </CardContent>
        </Card>

        {/* Recommendations */}
        {recommendations && recommendations.length > 0 && (
          <Card className="bg-gradient-to-br from-primary/5 to-chart-2/5">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Brain className="w-6 h-6 text-primary" />
                <CardTitle className="text-2xl">Recommended Next Steps</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Based on your performance, we recommend these quizzes to continue your learning journey:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {recommendations.slice(0, 2).map((quiz) => (
                  <Card key={quiz.id} className="hover-elevate transition-all">
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold text-lg line-clamp-1">{quiz.title}</h3>
                        <Badge variant="secondary" className="capitalize shrink-0">
                          {quiz.difficulty}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {quiz.description || quiz.topic}
                      </p>
                      <Link href={`/student/quiz/${quiz.id}`}>
                        <Button variant="outline" className="w-full" data-testid={`button-recommended-${quiz.id}`}>
                          Start Quiz
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 justify-center">
          <Link href="/student/dashboard">
            <Button variant="outline" size="lg" data-testid="button-dashboard">
              Back to Dashboard
            </Button>
          </Link>
          <Link href="/student/quizzes">
            <Button size="lg" data-testid="button-more-quizzes">
              Take Another Quiz
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
