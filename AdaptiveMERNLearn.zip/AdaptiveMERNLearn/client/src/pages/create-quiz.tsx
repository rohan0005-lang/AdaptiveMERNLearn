import { useState } from "react";
import { useLocation } from "wouter";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { insertQuizSchema, questionSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Save } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const createQuizFormSchema = insertQuizSchema.omit({ createdBy: true });

export function CreateQuiz() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof createQuizFormSchema>>({
    resolver: zodResolver(createQuizFormSchema),
    defaultValues: {
      title: "",
      description: "",
      difficulty: "medium",
      topic: "",
      questions: [
        {
          id: crypto.randomUUID(),
          question: "",
          options: ["", "", "", ""],
          correctAnswer: 0,
        },
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "questions",
  });

  const createQuizMutation = useMutation({
    mutationFn: async (data: z.infer<typeof createQuizFormSchema>) => {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      return await apiRequest("POST", "/api/quizzes", { ...data, createdBy: user.id });
    },
    onSuccess: () => {
      toast({ title: "Quiz created successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/quizzes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/stats"] });
      setLocation("/teacher/dashboard");
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to create quiz", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: z.infer<typeof createQuizFormSchema>) => {
    createQuizMutation.mutate(data);
  };

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-8">
      <div className="space-y-2">
        <h1 className="font-heading font-bold text-3xl md:text-4xl" data-testid="text-page-title">
          Create New Quiz
        </h1>
        <p className="text-muted-foreground text-lg">
          Design an engaging quiz for your students
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Quiz Details */}
          <Card>
            <CardHeader>
              <CardTitle>Quiz Details</CardTitle>
              <CardDescription>Basic information about your quiz</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quiz Title *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., Introduction to JavaScript" 
                        data-testid="input-title"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Brief description of what this quiz covers..."
                        rows={3}
                        data-testid="input-description"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Help students understand what they'll be tested on
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="topic"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Topic *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Mathematics, Science" 
                          data-testid="input-topic"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Difficulty *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-difficulty">
                            <SelectValue placeholder="Select difficulty" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="easy">Easy</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="hard">Hard</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Questions */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Questions</CardTitle>
                  <CardDescription>Add questions and answer choices</CardDescription>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => append({
                    id: crypto.randomUUID(),
                    question: "",
                    options: ["", "", "", ""],
                    correctAnswer: 0,
                  })}
                  data-testid="button-add-question"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Question
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              {fields.map((field, questionIndex) => (
                <div key={field.id} className="space-y-6 pb-8 border-b last:border-0">
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="font-semibold text-lg">Question {questionIndex + 1}</h3>
                    {fields.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => remove(questionIndex)}
                        data-testid={`button-remove-question-${questionIndex}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  <FormField
                    control={form.control}
                    name={`questions.${questionIndex}.question`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Question Text *</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter your question here..."
                            rows={2}
                            data-testid={`input-question-${questionIndex}`}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-4">
                    <FormLabel>Answer Options *</FormLabel>
                    {[0, 1, 2, 3].map((optionIndex) => (
                      <div key={optionIndex} className="flex items-start gap-3">
                        <div className="flex items-center h-10">
                          <input
                            type="radio"
                            name={`question-${questionIndex}-correct`}
                            checked={form.watch(`questions.${questionIndex}.correctAnswer`) === optionIndex}
                            onChange={() => form.setValue(`questions.${questionIndex}.correctAnswer`, optionIndex)}
                            className="w-4 h-4 text-primary"
                            data-testid={`radio-correct-${questionIndex}-${optionIndex}`}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name={`questions.${questionIndex}.options.${optionIndex}`}
                          render={({ field }) => (
                            <FormItem className="flex-1">
                              <FormControl>
                                <Input 
                                  placeholder={`Option ${optionIndex + 1}`}
                                  data-testid={`input-option-${questionIndex}-${optionIndex}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    ))}
                    <p className="text-xs text-muted-foreground">
                      Select the radio button next to the correct answer
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation("/teacher/dashboard")}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              size="lg"
              disabled={createQuizMutation.isPending}
              data-testid="button-save-quiz"
            >
              {createQuizMutation.isPending ? (
                "Creating..."
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Create Quiz
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
