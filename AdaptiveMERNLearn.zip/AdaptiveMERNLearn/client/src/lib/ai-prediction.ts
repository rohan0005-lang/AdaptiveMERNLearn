import * as tf from '@tensorflow/tfjs';
import type { Result } from '@shared/schema';

/**
 * Simple AI prediction model using TensorFlow.js
 * Predicts next quiz score based on historical performance
 */

export async function predictNextScore(results: Result[]): Promise<number> {
  if (!results || results.length === 0) {
    return 0;
  }

  // If only one result, use simple heuristic
  if (results.length === 1) {
    const lastScore = results[0].score;
    const lastAccuracy = results[0].accuracy;
    // Predict slight improvement or maintenance
    return Math.min(100, Math.round((lastScore + lastAccuracy) / 2 + 5));
  }

  try {
    // Extract features from results
    const scores = results.map(r => r.score);
    const accuracies = results.map(r => r.accuracy);
    const times = results.map(r => r.timeTaken);

    // Calculate trend metrics
    const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
    const avgAccuracy = accuracies.reduce((a, b) => a + b, 0) / accuracies.length;
    const avgTime = times.reduce((a, b) => a + b, 0) / times.length;

    // Calculate improvement trend (recent vs older performance)
    const recentScores = scores.slice(-3);
    const olderScores = scores.slice(0, Math.max(1, scores.length - 3));
    const recentAvg = recentScores.reduce((a, b) => a + b, 0) / recentScores.length;
    const olderAvg = olderScores.reduce((a, b) => a + b, 0) / olderScores.length;
    const trend = recentAvg - olderAvg;

    // Get last performance
    const lastScore = scores[scores.length - 1];
    const lastAccuracy = accuracies[accuracies.length - 1];

    // Create a simple linear regression model
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [4], units: 8, activation: 'relu' }),
        tf.layers.dense({ units: 4, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'linear' })
      ]
    });

    // Compile the model
    model.compile({
      optimizer: tf.train.adam(0.01),
      loss: 'meanSquaredError'
    });

    // Prepare training data
    const features: number[][] = [];
    const labels: number[] = [];

    for (let i = 0; i < results.length - 1; i++) {
      features.push([
        results[i].score,
        results[i].accuracy,
        results[i].timeTaken / 60, // Convert to minutes
        i / results.length // Position in sequence (normalized)
      ]);
      labels.push(results[i + 1].score);
    }

    if (features.length > 0) {
      // Train the model
      const xs = tf.tensor2d(features);
      const ys = tf.tensor2d(labels, [labels.length, 1]);

      await model.fit(xs, ys, {
        epochs: 50,
        shuffle: true,
        verbose: 0
      });

      // Make prediction
      const predictionInput = tf.tensor2d([[
        lastScore,
        lastAccuracy,
        times[times.length - 1] / 60,
        1.0 // Latest position
      ]]);

      const prediction = model.predict(predictionInput) as tf.Tensor;
      const predictedScore = (await prediction.data())[0];

      // Clean up tensors
      xs.dispose();
      ys.dispose();
      predictionInput.dispose();
      prediction.dispose();
      model.dispose();

      // Apply constraints and adjustments
      let finalPrediction = Math.round(predictedScore);

      // Add trend-based adjustment
      finalPrediction += Math.round(trend * 0.5);

      // Ensure realistic bounds
      finalPrediction = Math.max(0, Math.min(100, finalPrediction));

      // Don't predict dramatic changes
      const maxChange = 15;
      if (Math.abs(finalPrediction - lastScore) > maxChange) {
        finalPrediction = lastScore + Math.sign(finalPrediction - lastScore) * maxChange;
      }

      return finalPrediction;
    }

    // Fallback to simple prediction
    return Math.min(100, Math.max(0, Math.round(avgScore + trend)));
  } catch (error) {
    console.error('AI prediction error:', error);
    
    // Fallback: use simple average with trend
    const avgScore = results.reduce((sum, r) => sum + r.score, 0) / results.length;
    const lastScore = results[results.length - 1].score;
    const trend = lastScore - avgScore;
    
    return Math.min(100, Math.max(0, Math.round(lastScore + trend * 0.5)));
  }
}

/**
 * Get confidence level for the prediction
 */
export function getPredictionConfidence(results: Result[]): 'low' | 'medium' | 'high' {
  if (results.length < 3) return 'low';
  if (results.length < 7) return 'medium';
  return 'high';
}

/**
 * Generate learning insights based on results
 */
export function generateInsights(results: Result[]): string[] {
  if (!results || results.length === 0) return [];

  const insights: string[] = [];
  const scores = results.map(r => r.score);
  const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
  
  // Trend analysis
  if (scores.length >= 3) {
    const recent = scores.slice(-3).reduce((a, b) => a + b, 0) / 3;
    const older = scores.slice(0, -3).reduce((a, b) => a + b, 0) / (scores.length - 3);
    
    if (recent > older + 10) {
      insights.push("📈 You're showing great improvement! Keep up the momentum.");
    } else if (recent < older - 10) {
      insights.push("📉 Your recent scores have dipped. Consider reviewing fundamentals.");
    } else {
      insights.push("📊 Your performance is steady. Challenge yourself with harder topics!");
    }
  }

  // Consistency analysis
  const variance = scores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) / scores.length;
  if (variance < 100) {
    insights.push("🎯 You're very consistent! This shows strong foundational understanding.");
  } else if (variance > 300) {
    insights.push("⚡ Your scores vary widely. Focus on consistent study habits.");
  }

  // Time analysis
  if (results.length >= 3) {
    const avgTime = results.reduce((sum, r) => sum + r.timeTaken, 0) / results.length;
    const lastTime = results[results.length - 1].timeTaken;
    
    if (lastTime < avgTime * 0.7) {
      insights.push("⏱️ You're completing quizzes faster. Ensure you're not rushing!");
    } else if (lastTime > avgTime * 1.5) {
      insights.push("🔍 You're taking more time. Careful analysis is good!");
    }
  }

  // Performance level
  if (avgScore >= 85) {
    insights.push("🌟 Excellent work! You've mastered these topics.");
  } else if (avgScore >= 70) {
    insights.push("👍 Good performance! You're on the right track.");
  } else if (avgScore >= 50) {
    insights.push("💪 Keep practicing! You're making progress.");
  } else {
    insights.push("📚 Focus on fundamentals. Consider reviewing the basics.");
  }

  return insights.slice(0, 3); // Return top 3 insights
}
