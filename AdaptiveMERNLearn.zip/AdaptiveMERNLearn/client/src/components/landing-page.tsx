import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, BarChart3, Target, Zap, Users, TrendingUp } from "lucide-react";

export function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 md:px-8 py-16">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-chart-2/5 -z-10" />
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <h1 className="font-heading font-bold text-4xl md:text-5xl lg:text-6xl leading-tight text-foreground">
              Adaptive Learning That Grows With You
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Experience AI-powered personalized learning that adapts to your pace. 
              Get intelligent quiz recommendations and performance predictions to master any topic faster.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/login?role=student">
                <Button size="lg" className="text-base px-8" data-testid="button-student-login">
                  Student Login
                </Button>
              </Link>
              <Link href="/login?role=teacher">
                <Button size="lg" variant="outline" className="text-base px-8" data-testid="button-teacher-login">
                  Teacher Login
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="relative hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-chart-2/20 rounded-3xl blur-3xl" />
            <div className="relative bg-card/50 backdrop-blur-sm border border-card-border rounded-2xl p-8 space-y-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10">
                  <Brain className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-lg">AI-Powered Learning</div>
                  <div className="text-sm text-muted-foreground">Personalized to your pace</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-chart-2/10">
                  <TrendingUp className="w-8 h-8 text-chart-2" />
                </div>
                <div>
                  <div className="font-semibold text-lg">Smart Predictions</div>
                  <div className="text-sm text-muted-foreground">Know your progress ahead</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-chart-4/10">
                  <Target className="w-8 h-8 text-chart-4" />
                </div>
                <div>
                  <div className="font-semibold text-lg">Targeted Practice</div>
                  <div className="text-sm text-muted-foreground">Focus on what matters</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4 md:px-8 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="font-heading font-semibold text-3xl md:text-4xl text-foreground">
              Why Choose LearnAI?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our platform uses cutting-edge AI to create a truly personalized learning experience
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-personalized">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-primary/10 w-fit">
                  <Brain className="w-10 h-10 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-xl">Personalized Learning</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our AI adapts to your learning style and pace, ensuring you get the most out of every session.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-predictions">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-chart-2/10 w-fit">
                  <BarChart3 className="w-10 h-10 text-chart-2" />
                </div>
                <h3 className="font-heading font-semibold text-xl">AI Predictions</h3>
                <p className="text-muted-foreground leading-relaxed">
                  See your predicted performance before taking a quiz. Know where you stand and track your growth.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-analytics">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-chart-3/10 w-fit">
                  <TrendingUp className="w-10 h-10 text-chart-3" />
                </div>
                <h3 className="font-heading font-semibold text-xl">Deep Analytics</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Visualize your learning journey with interactive charts showing trends and insights.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-quizzes">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-chart-4/10 w-fit">
                  <Target className="w-10 h-10 text-chart-4" />
                </div>
                <h3 className="font-heading font-semibold text-xl">Smart Quizzes</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Take quizzes tailored to your skill level with instant feedback and detailed explanations.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-recommendations">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-chart-5/10 w-fit">
                  <Zap className="w-10 h-10 text-chart-5" />
                </div>
                <h3 className="font-heading font-semibold text-xl">Smart Recommendations</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Get topic suggestions based on your performance to optimize your learning path.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-feature-teacher">
              <CardContent className="p-8 space-y-4">
                <div className="p-4 rounded-xl bg-primary/10 w-fit">
                  <Users className="w-10 h-10 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-xl">For Teachers</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Create quizzes, track student progress, and gain insights into class performance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 px-4 md:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="font-heading font-semibold text-3xl md:text-4xl text-foreground">
              How It Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Start your adaptive learning journey in three simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="relative text-center space-y-4">
              <div className="mx-auto w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold">
                1
              </div>
              <h3 className="font-heading font-semibold text-xl">Sign Up</h3>
              <p className="text-muted-foreground">
                Create your account as a student or teacher in seconds
              </p>
            </div>

            <div className="relative text-center space-y-4">
              <div className="mx-auto w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold">
                2
              </div>
              <h3 className="font-heading font-semibold text-xl">Take Quizzes</h3>
              <p className="text-muted-foreground">
                Complete quizzes and let our AI analyze your performance
              </p>
            </div>

            <div className="relative text-center space-y-4">
              <div className="mx-auto w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold">
                3
              </div>
              <h3 className="font-heading font-semibold text-xl">Learn & Grow</h3>
              <p className="text-muted-foreground">
                Get personalized recommendations and watch your skills improve
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-4 md:px-8 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-primary font-heading">95%</div>
              <div className="text-sm md:text-base text-muted-foreground">Accuracy Rate</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-chart-2 font-heading">10k+</div>
              <div className="text-sm md:text-base text-muted-foreground">Active Students</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-chart-4 font-heading">50k+</div>
              <div className="text-sm md:text-base text-muted-foreground">Quizzes Completed</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl md:text-5xl font-bold text-chart-5 font-heading">98%</div>
              <div className="text-sm md:text-base text-muted-foreground">Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 md:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-primary/10 via-background to-chart-2/10 border-primary/20">
            <CardContent className="p-12 text-center space-y-6">
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-foreground">
                Ready to Transform Your Learning?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Join thousands of students already learning smarter with AI-powered adaptive education
              </p>
              <div className="flex flex-wrap justify-center gap-4 pt-4">
                <Link href="/signup">
                  <Button size="lg" className="text-base px-8" data-testid="button-signup-cta">
                    Get Started Free
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
