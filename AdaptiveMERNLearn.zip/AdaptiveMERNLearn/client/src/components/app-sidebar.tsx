import { useLocation, Link } from "wouter";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupLabel, 
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { LayoutDashboard, FileQuestion, BarChart3, User, LogOut, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AppSidebarProps {
  role: "student" | "teacher";
  userName: string;
  onLogout: () => void;
}

export function AppSidebar({ role, userName, onLogout }: AppSidebarProps) {
  const [location] = useLocation();

  const studentItems = [
    { title: "Dashboard", url: "/student/dashboard", icon: LayoutDashboard },
    { title: "Take Quizzes", url: "/student/quizzes", icon: FileQuestion },
    { title: "Analytics", url: "/student/analytics", icon: BarChart3 },
    { title: "Profile", url: "/student/profile", icon: User },
  ];

  const teacherItems = [
    { title: "Dashboard", url: "/teacher/dashboard", icon: LayoutDashboard },
    { title: "My Quizzes", url: "/teacher/quizzes", icon: FileQuestion },
    { title: "Create Quiz", url: "/teacher/create-quiz", icon: FileQuestion },
    { title: "Profile", url: "/teacher/profile", icon: User },
  ];

  const items = role === "student" ? studentItems : teacherItems;

  return (
    <Sidebar>
      <SidebarHeader className="p-6">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Brain className="w-6 h-6 text-primary" />
          </div>
          <div>
            <div className="font-heading font-semibold text-lg">LearnAI</div>
            <div className="text-xs text-muted-foreground capitalize">{role}</div>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location === item.url}
                    data-testid={`sidebar-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Link href={item.url} className="flex items-center gap-3">
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="space-y-3">
          <div className="px-3 py-2 bg-card rounded-lg">
            <div className="text-sm font-medium truncate">{userName}</div>
            <div className="text-xs text-muted-foreground">{role === "teacher" ? "Educator" : "Learner"}</div>
          </div>
          <Button 
            variant="outline" 
            className="w-full justify-start" 
            onClick={onLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
