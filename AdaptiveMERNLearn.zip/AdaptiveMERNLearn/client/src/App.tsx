import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { LandingPage } from "@/components/landing-page";
import { AuthPage } from "@/components/auth/auth-page";
import { StudentDashboard } from "@/pages/student-dashboard";
import { TeacherDashboard } from "@/pages/teacher-dashboard";
import { QuizList } from "@/pages/quiz-list";
import { QuizTaking } from "@/pages/quiz-taking";
import { QuizResults } from "@/pages/quiz-results";
import { Analytics } from "@/pages/analytics";
import { CreateQuiz } from "@/pages/create-quiz";
import NotFound from "@/pages/not-found";
import { useEffect, useState } from "react";

function ProtectedRoute({ children, requiredRole }: { children: React.ReactNode; requiredRole?: "student" | "teacher" }) {
  const [, setLocation] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");
    
    if (!token || !userStr) {
      setLocation("/login");
      return;
    }

    try {
      const user = JSON.parse(userStr);
      if (requiredRole && user.role !== requiredRole) {
        setLocation(user.role === "teacher" ? "/teacher/dashboard" : "/student/dashboard");
        return;
      }
      setIsAuthenticated(true);
    } catch {
      setLocation("/login");
    } finally {
      setIsLoading(false);
    }
  }, [requiredRole, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return isAuthenticated ? <>{children}</> : null;
}

function DashboardLayout({ children, role }: { children: React.ReactNode; role: "student" | "teacher" }) {
  const [, setLocation] = useLocation();
  const userStr = localStorage.getItem("user");
  const user = userStr ? JSON.parse(userStr) : null;

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setLocation("/");
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar role={role} userName={user?.name || "User"} onLogout={handleLogout} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b bg-background sticky top-0 z-10">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </header>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={LandingPage} />
      <Route path="/login">
        {(params) => {
          const urlParams = new URLSearchParams(window.location.search);
          const role = urlParams.get("role") as "student" | "teacher" | null;
          return <AuthPage initialMode="login" role={role || "student"} />;
        }}
      </Route>
      <Route path="/signup">
        <AuthPage initialMode="signup" role="student" />
      </Route>

      {/* Student Routes */}
      <Route path="/student/dashboard">
        <ProtectedRoute requiredRole="student">
          <DashboardLayout role="student">
            <StudentDashboard />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/student/quizzes">
        <ProtectedRoute requiredRole="student">
          <DashboardLayout role="student">
            <QuizList />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/student/quiz/:id">
        <ProtectedRoute requiredRole="student">
          <QuizTaking />
        </ProtectedRoute>
      </Route>
      <Route path="/student/results/:id">
        <ProtectedRoute requiredRole="student">
          <QuizResults />
        </ProtectedRoute>
      </Route>
      <Route path="/student/analytics">
        <ProtectedRoute requiredRole="student">
          <DashboardLayout role="student">
            <Analytics />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>

      {/* Teacher Routes */}
      <Route path="/teacher/dashboard">
        <ProtectedRoute requiredRole="teacher">
          <DashboardLayout role="teacher">
            <TeacherDashboard />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/teacher/quizzes">
        <ProtectedRoute requiredRole="teacher">
          <DashboardLayout role="teacher">
            <TeacherDashboard />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/teacher/create-quiz">
        <ProtectedRoute requiredRole="teacher">
          <DashboardLayout role="teacher">
            <CreateQuiz />
          </DashboardLayout>
        </ProtectedRoute>
      </Route>

      {/* 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
