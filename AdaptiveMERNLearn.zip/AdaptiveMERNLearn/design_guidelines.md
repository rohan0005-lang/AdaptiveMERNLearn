# Adaptive Learning Platform - Design Guidelines

## Design Approach

**Selected System:** Material Design principles with educational platform best practices (Khan Academy, Coursera inspiration)

**Justification:** Educational platforms require clear information hierarchy, data-dense layouts, and consistent patterns that support focused learning. Material Design provides excellent components for dashboards, data visualization, and form interactions.

**Core Principles:**
- Clarity over decoration: Information should be scannable and digestible
- Progressive disclosure: Show relevant content based on user role and context
- Trust and professionalism: Clean, credible design that inspires confidence
- Distraction-free learning: Minimal animations, focused interfaces

## Typography

**Font Stack:**
- **Primary:** Inter (Google Fonts) - UI elements, body text, data
- **Accent:** Poppins (Google Fonts) - Headings, hero sections, important callouts

**Hierarchy:**
- Hero Headlines: Poppins, 3xl-4xl (48-56px), font-bold
- Section Headings: Poppins, 2xl-3xl (32-40px), font-semibold
- Card Titles: Inter, xl (20px), font-semibold
- Body Text: Inter, base (16px), font-normal
- Small Text/Labels: Inter, sm (14px), font-medium
- Data/Metrics: Inter, 2xl-3xl, font-bold (for statistics)

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8, 12, 16** (e.g., p-4, gap-6, mb-8, py-12)

**Container Strategy:**
- Marketing pages: max-w-7xl with px-4 md:px-8
- Dashboard layouts: max-w-screen-2xl with full-width sections
- Content areas: max-w-4xl for optimal reading
- Form containers: max-w-md for focused inputs

**Grid Patterns:**
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Quiz questions: Single column, max-w-3xl centered
- Analytics: grid-cols-1 lg:grid-cols-2 for side-by-side charts
- Teacher quiz list: grid-cols-1 gap-4 (stacked cards)

## Component Library

### Navigation
**Header:** Full-width, sticky top navigation with logo left, navigation center, user profile/logout right. Height: h-16. Backdrop blur effect (backdrop-blur-sm) with subtle border-bottom.

**Sidebar (Dashboard):** Fixed left sidebar (w-64) for desktop, collapsible drawer for mobile. Sections for Dashboard, Quizzes, Progress/Analytics, Profile. Active state with accent background.

### Dashboard Components

**Student Dashboard:**
- **Progress Overview Card:** Large card (p-6) featuring circular progress indicator (% complete), current streak, total quizzes completed. Grid of 3 statistics using grid-cols-3.
- **Recommended Topics:** 2-column grid (md:grid-cols-2) of topic cards with icon, title, difficulty badge, and "Start Learning" button.
- **Recent Quiz Results:** Table or card list showing quiz name, score, date, AI prediction badge. Use alternating row backgrounds for readability.
- **Performance Chart:** Line chart showing score trends over time, full-width card with p-6 padding.

**Teacher Dashboard:**
- **Quick Stats Bar:** 4-column grid (grid-cols-2 lg:grid-cols-4) showing total students, total quizzes, average score, active learners. Each stat in a card with large number (3xl) and label.
- **Quiz Management Table:** Full-width table with columns: Title, Difficulty, Questions, Created Date, Actions (Edit/Delete/View Results). Hover states on rows.
- **Create Quiz Button:** Prominent FAB (Floating Action Button) or primary button in top-right.

### Quiz Interface

**Quiz Taking View:**
- Clean, distraction-free layout with progress bar at top (showing question X of Y)
- Question card: Large card (max-w-3xl mx-auto, p-8) with question text (xl font-size), answer options as radio button cards with full-width hover states
- Navigation: Previous/Next buttons at bottom, Submit Quiz when complete
- Timer (optional): Top-right corner, subtle styling

**Quiz Results:**
- Hero-style results card: Large score display (4xl), congratulatory message, AI prediction badge
- Question-by-question breakdown: Accordion or cards showing correct/incorrect answers
- Recommendations section: "Based on your performance, we recommend..." with topic cards
- Retry/Continue buttons

### Analytics Components
- **Chart Cards:** Each chart in its own card (p-6) with title, description, and legend
- **Chart Types:** Line charts for trends, bar charts for comparisons, donut charts for distributions
- **Filters:** Dropdown filters (time range, subject) in top-right of analytics section

### Forms & Inputs
- **Input Fields:** Full-width with labels above, rounded-lg borders, focus:ring states
- **Buttons:** 
  - Primary: Full saturation, medium padding (px-6 py-3), rounded-lg
  - Secondary: Outline style with hover fill
  - Danger: For delete actions
- **Quiz Creation Form:** Multi-step wizard or single long form with clear sections (Quiz Details, Add Questions, Review)

### Cards & Content Blocks
- **Standard Card:** rounded-xl, p-6, subtle shadow (shadow-sm), border or background differentiation
- **Interactive Cards:** Hover lift effect (hover:shadow-lg transition) for clickable cards
- **Stat Cards:** Larger padding (p-8), centered content, bold numbers
- **Topic/Quiz Cards:** Image/icon at top (if applicable), title, description (2 lines max), metadata (difficulty, duration), action button

### Badges & Labels
- **Difficulty Badges:** Rounded-full px-3 py-1 text-xs: Easy (green tone), Medium (yellow tone), Hard (red tone)
- **AI Prediction Badge:** Special styling with gradient or icon, "AI Predicted: 85%" format
- **Status Indicators:** Completed (checkmark), In Progress (partial circle), Locked (lock icon)

## Images

**Hero Section (Landing/Marketing):**
- **Primary Hero Image:** Illustration or photo of diverse students learning with technology (laptops, tablets). Place as background with overlay or split-screen (60/40 layout - content left, image right). Image should convey collaboration and success.

**Dashboard Illustrations:**
- **Empty States:** Friendly illustrations when no quizzes or results exist ("Start your learning journey" with student character)
- **Achievement Graphics:** Small celebratory graphics when milestones reached

**No large background images on dashboard pages** - keep them focused and data-driven.

## Page-Specific Layouts

### Landing Page (Public)
- **Hero:** Full-viewport (min-h-screen) with split layout - headline/CTA left, hero image right. Headline: "Adaptive Learning That Grows With You", subheading explaining AI-powered personalization, two CTAs (Student Login, Teacher Login).
- **Features Section:** 3-column grid (lg:grid-cols-3) with icons, titles, descriptions for Personalized Learning, AI Predictions, Analytics.
- **How It Works:** Numbered steps (3-4 cards) in horizontal flow explaining student/teacher journey.
- **Statistics Section:** 4 impressive metrics in grid-cols-2 lg:grid-cols-4 format.
- **CTA Section:** Full-width with gradient background, centered text and button.

### Authentication Pages
- **Layout:** Centered card (max-w-md) on minimal background, logo at top, form in middle, toggle link at bottom (Student/Teacher switch).
- **Form:** Email, password inputs, remember me checkbox, submit button, "Forgot password?" link.

### Student Dashboard (After Login)
- **Layout:** Sidebar navigation + main content area (ml-64 on desktop)
- **Sections:** Welcome banner with name, Progress Overview (top), Recommended Topics (middle), Recent Quizzes (bottom), Performance Chart (bottom)

### Teacher Dashboard
- **Layout:** Same sidebar structure
- **Sections:** Quick Stats (top), Quiz Management (center - table or grid), Student Performance Summary (side panel or bottom section)

### Quiz Taking Page
- **Layout:** Centered quiz card (max-w-3xl), minimal chrome, progress bar above, navigation below

### Analytics Page
- **Layout:** Grid of chart cards (2 columns on desktop), filters at top-right
- **Charts:** Score trends over time, topic performance comparison, quiz completion rates, time spent per topic

## Accessibility & Polish
- High contrast text (WCAG AA minimum)
- Focus visible states on all interactive elements
- Keyboard navigation for quiz taking
- Loading states for AI predictions and data fetching
- Error states with helpful messages
- Responsive breakpoints: sm (640px), md (768px), lg (1024px), xl (1280px)